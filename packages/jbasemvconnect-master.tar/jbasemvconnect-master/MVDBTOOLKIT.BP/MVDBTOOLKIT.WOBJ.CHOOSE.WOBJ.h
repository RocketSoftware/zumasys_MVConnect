* Code to determine default wobj library to use

* This needs to change for MVDBTOOLKIT build, defaults to WOBJ

WOBJ.RTNE="WOBJ"

NO.MD.FILE=0

OPEN "MD" TO FILE.MD ELSE
    OPEN "VOC" TO FILE.MD ELSE NO.MD.FILE=1
END

IF NOT(NO.MD.FILE) THEN
    READ WOBJ.CONF FROM FILE.MD, "WOBJ.CONF" ELSE WOBJ.CONF=""

    IF WOBJ.CONF<3> # "" THEN WOBJ.RTNE=WOBJ.CONF<3>
END
