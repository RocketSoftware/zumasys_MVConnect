# jbasemvconnect

 - Install jBASE/MVConnect Generic.  It installs into /home/jbase/MVDB
 - LOGTO JBASEMVCONNECT
 - Git project is /home/jbasemvconnect
 - TOOLS.BP COPY.FROM.MVDB will copy over the items
 - LOGTO JBASEMVCONNECTTEST
 - CATALOG WREST.BP
 - CATALOG WOBJ.BP
 - CATALOG MVDBTOOLKIT.BP
 - 
 
Issues
 - WDEBUG is getting overwritten
